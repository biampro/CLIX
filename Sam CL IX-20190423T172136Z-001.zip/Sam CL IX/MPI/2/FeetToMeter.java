 import mpi.MPI;

    public class FeetToMeter {
   	 public static void main(String args[]){
	//Initialize MPI execution environment
   	 MPI.Init(args);
	//Get the id of the process
   	 int rank = MPI.COMM_WORLD.Rank();
	//total number of processes is stored in size
   	 int size = MPI.COMM_WORLD.Size();
   	 int root=0;
	//array which will be filled with data by root process
   	 double sendbuf[]=null;

   	 sendbuf= new double[size];

	//creates data to be scattered
   	 if(rank==root){
   		 sendbuf[0] = 10;
   		 sendbuf[1] = 20;
   		 sendbuf[2] = 30;
   		 sendbuf[3] = 40;

		//print current process number
   		 System.out.print("Processor "+rank+" has data: ");
   		 for(int i = 0; i < size; i++){
   			 System.out.print(sendbuf[i]+" ");
   		 }
   		 System.out.println();
   	 }
	//collect data in recvbuf
   	 double recvbuf[] = new double[1];
	
	//following are the args of Scatter method
	//send, offset, chunk_count, chunk_data_type, recv, offset, chunk_count, chunk_data_type, root_process_id
   	 MPI.COMM_WORLD.Scatter(sendbuf, 0, 1, MPI.DOUBLE, recvbuf, 0, 1, MPI.DOUBLE, root);
   	 System.out.println("Processor "+rank+" has data: "+recvbuf[0]);
   	 System.out.println("Processor "+rank+" is converting into meter");
   	 recvbuf[0]=recvbuf[0]*0.305;
	//following are the args of Gather method
	//Object sendbuf, int sendoffset, int sendcount, Datatype sendtype,
//Object recvbuf, int recvoffset, int recvcount, Datatype recvtype,
//int root)
   	 MPI.COMM_WORLD.Gather(recvbuf, 0, 1, MPI.DOUBLE, sendbuf, 0, 1, MPI.DOUBLE, root);
	//display the gathered result
   	 if(rank==root){
   		System.out.println("Process 0 has data: ");
   		 for(int i=0;i<4;i++){
   			 System.out.print(sendbuf[i]+ " ");
   		 }
   	 }
	//Terminate MPI execution environment 
   	 MPI.Finalize();
    }
}
/*

Output :

ashish@ubuntu:~$ export MPJ_HOME=/home/ashish/mpj-v0_44
ashish@ubuntu:~$ javac -cp $MPJ_HOME/lib/mpj.jar FeetToMeter.java
ashish@ubuntu:~$ $MPJ_HOME/bin/mpjrun.sh -np 4 FeetToMeter
MPJ Express (0.44) is started in the multicore configuration
Processor 0 has data: 10.0 20.0 30.0 40.0 
Processor 0 has data: 10.0
Processor 0 is converting into meter
Processor 3 has data: 40.0
Processor 3 is converting into meter
Processor 2 has data: 30.0
Processor 1 has data: 20.0
Processor 1 is converting into meter
Processor 2 is converting into meter
Process 0 has data: 
3.05 6.1 9.15 12.2 



*/
