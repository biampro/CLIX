import java.sql.*;
import java.rmi.*;
import java.io.*;
import java.util.*;
import java.util.Vector.*;
import java.lang.*;
import java.rmi.registry.*;
import java.util.Scanner;


public class Client
{
	static int number1,number2,result;
	static String op;
	
	public static void main(String args[])
	{
		Client c=new Client();
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		Scanner b = new Scanner(System.in);	
		
		try 
		{
			Registry r1 = LocateRegistry.getRegistry ( "localhost", 1030);
			DBInterface DI=(DBInterface)r1.lookup("DBServ");
					
			System.out.println(" \n Enter number 1 :");
			number1=b.nextInt();
			System.out.println("\n Enter number 2 :");
			number2 = b.nextInt();
			System.out.println("\nEnter operation : ");
			op=br.readLine();
			result=DI.input(number1,number2,op);
			System.out.println("Result is : "+result);
					
			
		}
		catch (Exception e)
		{
			// System.out.println("ERROR: " +e.getMessage());
		}
	}
}
