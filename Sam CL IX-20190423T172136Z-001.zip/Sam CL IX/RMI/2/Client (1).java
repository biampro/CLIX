
import java.io.*;

import java.rmi.registry.*;


public class Client
{
	static String name1,name2;
	static boolean name3;
	public static void main(String args[])
	{
		BufferedReader b = new BufferedReader(new InputStreamReader(System.in));
			
		try 
		{
			Registry r1 = LocateRegistry.getRegistry ( "localhost", 1030);
			DBInterface DI=(DBInterface)r1.lookup("DBServ");
			
				
				
			System.out.println("Enter first string:");
			name1=b.readLine();
			System.out.println(" \n Enter second string:");
			name2=b.readLine();
			
			name3=DI.input(name1,name2);
			if(name3==true)
			System.out.println("Yes");
			else
			System.out.println("No");

				
					
					
		}
		catch (Exception e)
		{
			// System.out.println("ERROR: " +e.getMessage());
		}
	}
}

