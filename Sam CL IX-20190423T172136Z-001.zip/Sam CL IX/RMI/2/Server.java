
//RMI Server //

import java.rmi.*;

import java.rmi.server.*;


//Interface is used for remote proceduce call. defined in server called by clients.

interface DBInterface extends Remote
{
	public boolean input(String name1,String name2) throws RemoteException;
}

public class Server extends UnicastRemoteObject implements DBInterface
{
	//int flag=0,n,i,j;
	//String name3;
	//ResultSet r;

	public Server() throws RemoteException
	{ 
		try
		{ 
			System.out.println("Initializing Server\nServer Ready");
		}
		catch (Exception e)
		{
			 System.out.println(e);
		}
	}

	// rmi registy is a place for the server to register services it offers and a place for client to query those services. 
	public static void main(String[] args)
	{ 
	try
	{
		Server rs=new Server();
		java.rmi.registry.LocateRegistry.createRegistry(1030).rebind("DBServ",rs);
	}
	catch (Exception e)
	{
		System.out.println(e);
	}
}

public boolean input(String name1,String name2)
{
boolean isfound=true;

try
{
	 isfound=name1.contains(name2);
}
catch (Exception e)
{
	System.out.println(e);
}

return isfound;
}
}

