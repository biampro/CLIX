import java.sql.*;
import java.rmi.*;
import java.io.*;
import java.util.*;
import java.util.Vector.*;
import java.lang.*;
import java.rmi.registry.*;
import java.util.Scanner;


public class Client
{
	static double fact;
	static int number;
	
	public static void main(String args[])
	{
		Client c=new Client();
		//BufferedReader b = new BufferedReader(new InputStreamReader(System.in));
		Scanner b = new Scanner(System.in);	
		int ch;
		try 
		{
			Registry r1 = LocateRegistry.getRegistry ( "localhost", 1030);
			DBInterface DI=(DBInterface)r1.lookup("DBServ");
					
			System.out.println(" \n Enter number:");
			number=b.nextInt();
			fact=DI.input(number);
			System.out.println("Square root is : "+fact);
					
			
		}
		catch (Exception e)
		{
			// System.out.println("ERROR: " +e.getMessage());
		}
	}
}
